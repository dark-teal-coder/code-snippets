# Update-Chrome.ps1 - Shows current & latest version clearly
# Works on Windows 10/11 • PowerShell 5.1 or 7+

$ErrorActionPreference = "Stop"

Write-Host "`n=== Google Chrome Auto-Update ===`n" -ForegroundColor Cyan

# --- Get currently installed version ---
$InstalledVersion = $null
$RegPaths = @(
    "HKLM:\SOFTWARE\Google\Chrome\BLBeacon"
    "HKLM:\SOFTWARE\WOW6432Node\Google\Chrome\BLBeacon"
    "HKCU:\SOFTWARE\Google\Chrome\BLBeacon"
)

foreach ($Path in $RegPaths) {
    if (Test-Path $Path) {
        $InstalledVersion = (Get-ItemProperty -Path $Path -Name version).version
        break
    }
}

if (-not $InstalledVersion) {
    Write-Host "Chrome is not installed on this computer." -ForegroundColor Red
    pause
    exit 1
}

Write-Host "Currently installed version : $InstalledVersion" -ForegroundColor Yellow

# --- Get latest stable version from Google ---
try {
    $LatestInfo = Invoke-RestMethod -Uri "https://versionhistory.googleapis.com/v1/chrome/platforms/win64/channels/stable/versions/latest" -TimeoutSec 15
    $LatestVersion = $LatestInfo.version
} catch {
    Write-Host "Failed to retrieve latest version (no internet?)" -ForegroundColor Red
    pause
    exit 1
}

Write-Host "Latest stable version       : $LatestVersion" -ForegroundColor Green

# --- Compare and update if needed ---
if ([version]$InstalledVersion -ge [version]$LatestVersion) {
    Write-Host "`nChrome is already up to date!" -ForegroundColor Green
} else {
    Write-Host "`nUpdate available! Downloading $LatestVersion ..." -ForegroundColor Magenta

    $Installer = "$env:TEMP\ChromeSetup.exe"
    $Url = "https://redirector.gvt1.com/edgedl/chrome/chrome-installer?platform=win64&channel=stable"

    Invoke-WebRequest -Uri $Url -OutFile $Installer -UseBasicParsing

    Write-Host "Installing silently ..." -ForegroundColor Cyan
    Start-Process -FilePath $Installer -ArgumentList "/silent","/install" -Wait -PassThru | Out-Null
    Remove-Item $Installer -Force

    Write-Host "`nChrome successfully updated to version $LatestVersion!" -ForegroundColor Green
}

Write-Host "`n=== Finished ===`n" -ForegroundColor Cyan
pause